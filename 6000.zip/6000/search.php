<?php 
require_once 'bin/submit.php';

if(isset($_REQUEST['id'])){
$id = mysqli_real_escape_string($con,$_REQUEST['id']);
if (!preg_match("/^[0-9]*$/",$id)) {
    alert("Adhaar Number is wrong $id");
    location("form.php");
    return false;
}
$ssql = mysqli_query($con, "SELECT * FROM info WHERE adhaar = '$id' AND flag = 1 ");
$sdata = mysqli_fetch_assoc($ssql);
$sn = $sdata['id'];
$date = $sdata['date'];
$phone = $sdata['phone'];
$s_card_no = $sdata['s_card_no'];
$name = $sdata['name'];
$guardian = $sdata['guardian'];
$age = $sdata['age'];
$status = $sdata['status'];
$adhaar = $sdata['adhaar'];
$pan = $sdata['doc_pan'];

$passbook = $sdata['doc_passbook'];
$business = $sdata['doc_ownbusiness'];
$legalFee = $sdata['legal_fee'];
$file_charge = $sdata['file_charge'];
$site_visit = $sdata['site_visit'];
$total = $sdata['total'];
}else if(isset($_REQUEST['upd'])){
    
$uid = mysqli_real_escape_string($con,$_REQUEST['upd']);
if (!preg_match("/^[0-9]*$/",$uid)) {
    alert("Adhaar Number is wrong $uid");
    location("form.php");
    return false;
}
$ssql = mysqli_query($con, "SELECT * FROM info WHERE adhaar = '$uid' AND flag = 1 ");
$sdata = mysqli_fetch_assoc($ssql);
$sn = $sdata['id'];
$date = $sdata['date'];
$phone = $sdata['phone'];
$s_card_no = $sdata['s_card_no'];
$name = $sdata['name'];
$guardian = $sdata['guardian'];
$age = $sdata['age'];
$status = $sdata['status'];
$adhaar = $sdata['adhaar'];
$pan = $sdata['doc_pan'];

$passbook = $sdata['doc_passbook'];
$business = $sdata['doc_ownbusiness'];
$legalFee = $sdata['legal_fee'];
$file_charge = $sdata['file_charge'];
$site_visit = $sdata['site_visit'];
$total = $sdata['total'];    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>SHREE ASSOCIATES</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="assets/bootstrap.min.csc">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css.css">
  <script src="assets/jquery.min.js"></script>
  <script src="assets/bootstrap.min.js"></script>
  <!-- <script src="assets/js.js"></script> -->
  <link href="assets/css.css" rel="stylesheet" type="text/css"/>
  
  <style>
      .left{
          float: left;
      }
      .right{
          float: right;
      }
  </style>
</head>
<body>

<div class="container">

    <div style="max-width: 100%">
<!--        <strong class="text-left"> GST NO. 07CPNPS0473P1Z1</strong>
        <strong class="text-right"> MOB: 9999999999</strong>-->
  
        <em><h1 class="text-center ">SHREE ASSOCIATES</h1></em>
        <p class="text-center">ALL TYPE FLATS:- LIG, MIG HIG, LAND AND PROPERTY, WITH BANK FINANCE</p>
        <p class="text-center">AND OWN FINANCE FACILITY AVAILABLE</p>
        <p class="text-center">Add:- B.M. Market, Main Road, Kartar Nagar, 4 th Pusta, Delhi-110053</p>
        
    </div>

    <div >
        <form action="search.php" method="get" class="left">
            <input  type="number" placeholder="  Search" name="id">
            <button class="glyphicon glyphicon-search btn btn-info"></button>
        </form>
        
        <form action="search.php" method="get" class="left">
            &nbsp;&nbsp;&nbsp;
            <input  type="number" placeholder="  Update" name="upd">
            <button class="glyphicon glyphicon-pencil btn btn-info"></button>
        </form>
         <a class="btn btn-info right" href="form.php">Add New User</a>
    </div>
    <br>
    <br>
<?php 
if(isset($_REQUEST['upd'])){
$uid = mysqli_real_escape_string($con,$_REQUEST['upd']);
if (!preg_match("/^[0-9]*$/",$uid)) {
    alert("Adhaar Number is wrong $uid");
    location("form.php");
    return false;
}
?>
<form class="well form-horizontal" action="bin/getup.php" method="post" autocomplete="off" id="contact_form">
<fieldset>

<!-- Form Name -->
<div style="max-width:100%">
<div class="form-group">
  <label class="col-md-2 control-label">File No.</label>  
  <div class="col-md-2 inputGroupContainer">
  <div class="input-group">
  
      <input disabled class="form-control"  value="AALS@<?php echo 100+$sn; ?>">
    </div>
  </div>
  
  <label class="col-md-1 control-label">DATE</label>  
  <div class="col-md-2 inputGroupContainer">
  <div class="input-group">
  
      <input  class="form-control" value="<?php echo trim(date("d-m-Y", strtotime($date))); ?>" name="form_date"  required type="text">
    </div>
	  
  </div>

  <label class="col-md-1 control-label">MOB:-</label>  
  <div class="col-md-2 inputGroupContainer">
  <div class="input-group">
  
      <input   maxlength="10" value="<?php echo trim(strtoupper($phone)); ?>" name="phone"  class="form-control" type="tel">
    </div>
  </div>
</div>

</div>

<!-- Text input-->

<div class="form-group">
  <label class="col-md-4 control-label">SOCIETY CARD NO. </label>  
  <div class="col-md-4 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-credit-card"></i></span>
  <input  class="form-control" value="<?php echo trim(strtoupper($s_card_no)); ?>" name="s_card_no" type="number">
    </div>
  </div>
</div>

<!-- Text input-->

<div class="form-group">
  <label class="col-md-4 control-label" >Name</label> 
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input class="form-control" value="<?php echo trim(strtoupper($name)); ?>" name="name" type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-4 control-label" >S/o W/o </label> 
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input value="<?php echo trim(strtoupper($guardian)); ?>"   class="form-control" name="guardian" type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-4 control-label" >Age</label> 
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input class="form-control" value="<?php echo trim(strtoupper($age)); ?>"  name="age"   type="number">
    </div>
  </div>
</div>
<div class="form-group">
    <label class="col-md-4 control-label">Select Status  </label>
    <div class="col-md-4">
        <div class="select">
            <select class="form-control" name="form_status" required onchange="status(this);" >
                
                <option value="<?php echo trim($status); ?>" selected ><?php echo trim(strtoupper($status)); ?></option>
                <?php 
                $arr = ["married","unmarried","widow","blind","handicap"];
                foreach ($arr as $value) {
                    if(trim($status) != $value){
                    ?>
                <option value="<?php echo trim($value); ?>"><?php echo trim(strtoupper($value)); ?></option>
                <?php
                } }
                ?>
<!--                <option value="married">Married</option>
                <option value="unmarried">Unmarried</option>
                <option value="widow">Widow</option>
                <option value="blind">Blind</option>
                <option value="handicap">Handicap</option>-->
            </select>
        </div>
        
    </div>
</div>

<strong class="col-md-12 col-md-offset-2"><h3 class="text-left">Documents:- </h3></strong>

<!-- Check Box input-->
<div class="form-group">
    <label class="col-md-4 control-label">Adhaar card </label>
    <div class="col-md-4">
        <div class="checkbox">
            <label>
                <input type="number"  name="adhaar" class="form-control" value="<?php echo trim(strtoupper($adhaar)); ?>"  /> 
            </label>
        </div>
        
    </div>
</div>
<div class="form-group">
    <label class="col-md-4 control-label">Pan card </label>
    <div class="col-md-4">
        <div class="checkbox">
            <label>
                <?php 
                if($pan == 1){
                ?>
                <input type="checkbox" checked name="pan" /> 
                <?php }else{ ?>
                <input type="checkbox" name="pan" /> 
                <?php } ?>
            </label>
        </div>
        
    </div>
</div>
<div class="form-group">
    <label class="col-md-4 control-label">Bank Passbook</label>
    <div class="col-md-4">
        <div class="checkbox">
            <label>
                <?php 
                if($passbook == 1){
                ?>
                <input type="checkbox" checked name="passbook" /> 
                <?php }else{ ?>
                <input type="checkbox" name="passbook" /> 
                <?php } ?>
            </label>
        </div>
        
    </div>
</div>
<div class="form-group">
    
    <?php 
    if($business == "service"){
    ?>
    <label class="col-md-4 control-label"><?php echo trim(strtoupper($business)); ?></label>
    <div class="col-md-1">
        <div class="radio">
            <label>
                <input type="radio" required value="service" checked name="ownBusiness" /> 
            </label>
        </div>
        
    </div>
    <label class="col-md-2 control-label">Own Business </label>
    <div class="col-md-1">
        <div class="radio">
            <label>
                <input type="radio" required value="business" name="ownBusiness" /> 
            </label>
        </div>
        
    </div>
    <?php } ?>
    <?php 
    if($business == "business"){
    ?>
    <label class="col-md-4 control-label">Service </label>
    <div class="col-md-1">
        <div class="radio">
            <label>
                <input type="radio" required value="service" name="ownBusiness" /> 
            </label>
        </div>
        
    </div>
    <label class="col-md-4 control-label"><?php echo trim(strtoupper($business)); ?></label>
    <div class="col-md-1">
        <div class="radio">
            <label>
                <input type="radio" required checked value="business" name="ownBusiness" /> 
            </label>
        </div>
        
    </div>

    <?php } ?>
</div>
<!-- Check Box input-->
<div class="form-group">
    <label class="col-md-4 control-label text-left">PROCESSING CHARGE </label>
    
</div>

<div class="row hd" id="na" style="border: 0.5px solid #b5b5b5;margin:1%;padding: 1%;">
       
    <div class="col-md-6">
        <div class="col-md-8">LEGAL FEE</div>
        <div class="col-md-4 wd hc">RS. 1000/-</div>
        <div class="col-md-8">FILE AND PAPER CHARGE</div>
        <div class="col-md-4 wd hc">RS. 90/-</div>
        <div class="col-md-8">SITES VISIT CHARGE</div>
        <div class="col-md-4 wd hc">RS. 110/-</div>
        <hr class="col-md-10" style="border: 0.5px solid #b5b5b5;margin: 0px" />
        <div class="col-md-8">SUB TOTAL</div>
        <div class="col-md-4 wd hc">RS. 1200/-</div>
        <div class="col-md-8">GST @ 18%</div>
        <div class="col-md-4 wd hc">RS. 216/-</div>
        <div class="col-md-8">TOTAL</div>
        <div class="col-md-4 wd hc">RS. 1416/-</div>
    </div>
    
</div>
<div class="row hd" id="wd" style="border: 0.5px solid #b5b5b5;margin:1%;padding: 1%;">
       
    <div class="col-md-6">
        <div class="col-md-8">LEGAL FEE</div>
        <div class="col-md-4 wd hc">RS. 500/-</div>
        <div class="col-md-8">FILE AND PAPER CHARGE</div>
        <div class="col-md-4 wd hc">RS. 45/-</div>
        <div class="col-md-8">SITES VISIT CHARGE</div>
        <div class="col-md-4 wd hc">RS. 55/-</div>
        <hr class="col-md-10" style="border: 0.5px solid #b5b5b5;margin: 0px">
        <div class="col-md-8">SUB TOTAL</div>
        <div class="col-md-4 wd hc">RS. 600/-</div>
        <div class="col-md-8">GST @ 18%</div>
        <div class="col-md-4 wd hc">RS. 108/-</div>
        <div class="col-md-8">TOTAL</div>
        <div class="col-md-4 wd hc">RS. 708/-</div>
    </div>
    
</div>
<div class="row hd" id="hc_bd" style="border: 0.5px solid #b5b5b5;margin:1%;padding: 1%;">
       
    <div class="col-md-6">
        <div class="col-md-8">LEGAL FEE</div>
        <div class="col-md-4 wd hc">RS. 1000/-</div>
        <div class="col-md-8">FILE AND PAPER CHARGE</div>
        <div class="col-md-4 wd hc">RS. 90/-</div>
        <div class="col-md-8">SITES VISIT CHARGE</div>
        <div class="col-md-4 wd hc">RS. 110/-</div>
        <hr class="col-md-10" style="border: 0.5px solid #b5b5b5;margin: 0px">
        <div class="col-md-8">SUB TOTAL</div>
        <div class="col-md-4 wd hc">RS. 1200/-</div>
        <div class="col-md-8">GST @ 18%</div>
        <div class="col-md-4 wd hc">RS. 216/-</div>
        <div class="col-md-8">TOTAL</div>
        <div class="col-md-4 wd hc">RS. 1416/-</div>
        <div class="col-md-8">DISCOUNT 100%</div>
<!--        <div class="col-md-4 wd hc"> 100%</div>-->
        <div class="col-md-8">TOTAL</div>
        <div class="col-md-4 wd hc">RS. 0/-</div>
    </div>
    
</div>


<!-- Text input-->
<div class="text-justify" style="padding:20px">
    If you visits all sites and after visiting all sites you will not interest to finance anyone of then
by any reason then the processing fees will not return and if you will purchase any flat then
your processing fees will be adjust in your flats/land amount.
</div>

<!-- Success message -->
<div class="alert alert-success" role="alert" id="success_message">Success <i class="glyphicon glyphicon-thumbs-up"></i> Thanks for contacting us, we will get back to you shortly.</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4">
     <button type="submit" name="update" onclick="confirm('Please verify all the information.')" class="btn btn-success" >Update <span class="glyphicon glyphicon-send"></span></button>
  </div>
</div>
<input type="hidden" name="hid" value="<?php echo trim($sn) ;?>"
</fieldset>
</form>
<?php    
}else{
?>
<form class="well form-horizontal"  id="contact_form">
<fieldset>

<!-- Form Name -->
<div style="max-width:100%">
<div class="form-group">
  <label class="col-md-2 control-label">File No.</label>  
  <div class="col-md-2 inputGroupContainer">
  <div class="input-group">
  
      <input disabled class="form-control"  value="AALS@<?php echo 100+$sn; ?>">
    </div>
  </div>
  
  <label class="col-md-1 control-label">DATE</label>  
  <div class="col-md-2 inputGroupContainer">
  <div class="input-group">
  
      <input  class="form-control" value="<?php echo trim(date("d-m-Y", strtotime($date))); ?>" disabled required type="text">
    </div>
	  
  </div>

  <label class="col-md-1 control-label">MOB:-</label>  
  <div class="col-md-2 inputGroupContainer">
  <div class="input-group">
  
      <input   maxlength="10" value="<?php echo trim(strtoupper($phone)); ?>" disabled  class="form-control" type="tel">
    </div>
  </div>
</div>

</div>

<!-- Text input-->

<div class="form-group">
  <label class="col-md-4 control-label">SOCIETY CARD NO. </label>  
  <div class="col-md-4 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-credit-card"></i></span>
  <input  class="form-control" value="<?php echo trim(strtoupper($s_card_no)); ?>" disabled type="number">
    </div>
  </div>
</div>

<!-- Text input-->

<div class="form-group">
  <label class="col-md-4 control-label" >Name</label> 
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input class="form-control" value="<?php echo trim(strtoupper($name)); ?>" disabled type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-4 control-label" >S/o W/o </label> 
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input value="<?php echo trim(strtoupper($guardian)); ?>" disabled  class="form-control"  type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-4 control-label" >Age</label> 
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input class="form-control" value="<?php echo trim(strtoupper($age)); ?>" disabled type="number">
    </div>
  </div>
</div>
<div class="form-group">
    <label class="col-md-4 control-label">Select Status  </label>
    <div class="col-md-4">
        <div class="select">
            <select class="form-control"  >
                <option value="<?php echo trim(strtoupper($status)); ?>"><?php echo trim(strtoupper($status)); ?></option>
                
            </select>
        </div>
        
    </div>
</div>

<strong class="col-md-12 col-md-offset-2"><h3 class="text-left">Documents:- </h3></strong>

<!-- Check Box input-->
<div class="form-group">
    <label class="col-md-4 control-label">Adhaar card </label>
    <div class="col-md-4">
        <div class="checkbox">
            <label>
                <input type="number" class="form-control" value="<?php echo trim(strtoupper($adhaar)); ?>" disabled /> 
            </label>
        </div>
        
    </div>
</div>
<div class="form-group">
    <label class="col-md-4 control-label">Pan card </label>
    <div class="col-md-4">
        <div class="checkbox">
            <label>
                <?php 
                if($pan == 1){
                ?>
                <input type="checkbox" checked name="pan" /> 
                <?php }else{ ?>
                <input type="checkbox" name="pan" /> 
                <?php } ?>
            </label>
        </div>
        
    </div>
</div>
<div class="form-group">
    <label class="col-md-4 control-label">Bank Passbook</label>
    <div class="col-md-4">
        <div class="checkbox">
            <label>
                <?php 
                if($passbook == 1){
                ?>
                <input type="checkbox" checked name="pan" /> 
                <?php }else{ ?>
                <input type="checkbox" name="pan" /> 
                <?php } ?>
            </label>
        </div>
        
    </div>
</div>
<div class="form-group">
    <?php 
    if(isset($business)){
    ?>
    <label class="col-md-4 control-label"><?php echo trim(strtoupper($business)); ?></label>
    <div class="col-md-1">
        <div class="radio">
            <label>
                <input type="radio" checked  /> 
            </label>
        </div>
        
    </div>
    <?php } ?>
</div>
<!-- Check Box input-->
<div class="form-group">
    <label class="col-md-4 control-label text-left">PROCESSING CHARGE </label>
    
</div>

<div class="col-md-12 "  style="border: 0.5px solid #b5b5b5;margin:1%;padding: 1%;">
       
    <div class="col-md-6">
        <?php  
                if($status == "blind" || $status == "handicap"){
          ?>
        <div class="col-md-8">LEGAL FEE</div>
        <div class="col-md-4 wd hc">RS. 1000/-</div>
        <div class="col-md-8">FILE AND PAPER CHARGE</div>
        <div class="col-md-4 wd hc">RS. 90/-</div>
        <div class="col-md-8">SITES VISIT CHARGE</div>
        <div class="col-md-4 wd hc">RS. 110/-</div>
        <hr class="col-md-10" style="border: 0.5px solid #b5b5b5;margin: 0px">
        <div class="col-md-8">SUB TOTAL</div>
        <div class="col-md-4 wd hc">RS. 1200/-</div>
        <div class="col-md-8">GST @ 18%</div>
        <div class="col-md-4 wd hc">RS. 216/-</div>
        <div class="col-md-8">TOTAL</div>
        <div class="col-md-4 wd hc">RS. 1416/-</div>
        <div class="col-md-8">DISCOUNT 100%</div>
<!--        <div class="col-md-4 wd hc"> 100%</div>-->
        <div class="col-md-8">TOTAL</div>
        <div class="col-md-4 wd hc">RS. 0/-</div>
        <?php 
                }else{
        ?>
        <div class="col-md-8">LEGAL FEE</div>
        <div class="col-md-4 wd hc">RS. <?php echo trim($legalFee); ?>/-</div>
        <div class="col-md-8">FILE AND PAPER CHARGE</div>
        <div class="col-md-4 wd hc">RS. <?php echo trim($file_charge); ?>/-</div>
        <div class="col-md-8">SITES VISIT CHARGE</div>
        <div class="col-md-4 wd hc">RS. <?php echo trim($site_visit); ?>/-</div>
        <hr class="col-md-10" style="border: 0.5px solid #b5b5b5;margin: 0px">
        <div class="col-md-8">SUB TOTAL</div>
        <div class="col-md-4 wd hc">RS. <?php echo $total_am = trim($legalFee+$file_charge+$site_visit); ?>/-</div>
        <div class="col-md-8">GST @ 18%</div>
        <div class="col-md-4 wd hc">RS. <?php echo $gst = $total_am*0.18; ?>/-</div>
        <div class="col-md-8">TOTAL</div>
        <div class="col-md-4 wd hc">RS. <?php echo trim($total); ?>/-</div>
        
                <?php } ?>
    </div>
    
</div>


<!-- Text input-->
<div class="text-justify" style="padding:20px">
    If you visits all sites and after visiting all sites you will not interest to finance anyone of then
by any reason then the processing fees will not return and if you will purchase any flat then
your processing fees will be adjust in your flats/land amount.
</div>

<!-- Success message -->
<div class="alert alert-success" role="alert" id="success_message">Success <i class="glyphicon glyphicon-thumbs-up"></i> Thanks for contacting us, we will get back to you shortly.</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4">
      <a class="btn btn-info" href="form.php">Add New User</a>

  </div>
</div>

</fieldset>
</form>
<?php 
}
?>
</div>
    </div><!-- /.container -->




</body>

<script>
    
function status(val){
//    alert(val.value);
    var get  = val.value; 
    
    if(get == "blind" || get == "handicap"){
        document.getElementById("hc_bd").style.display = "block";
        document.getElementById("wd").style.display = "none";
        document.getElementById("na").style.display = "none";
    
    }else if(get == "widow"){
        document.getElementById("wd").style.display = "block";
        document.getElementById("hc_bd").style.display = "none";
        document.getElementById("na").style.display = "none";
    }else{
        document.getElementById("na").style.display = "block";
        document.getElementById("hc_bd").style.display = "none";
        document.getElementById("wd").style.display = "none";
    }
    
}
</script>
</html>
