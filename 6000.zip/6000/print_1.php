<?php 
require_once 'bin/submit.php';

$id = mysqli_real_escape_string($con,$_REQUEST['id']);
if (!preg_match("/^[0-9]*$/",$id)) {
    alert("Adhaar Number is wrong $id");
    location("form.php");
    return false;
}

$ssql = mysqli_query($con, "SELECT * FROM info WHERE adhaar = '$id' AND flag = 1 ");
$sdata = mysqli_fetch_assoc($ssql);
$sn = $sdata['id'];
$date = $sdata['date'];
$phone = $sdata['phone'];
$s_card_no = $sdata['s_card_no'];
$name = $sdata['name'];
$guardian = $sdata['guardian'];
$age = $sdata['age'];
$status = $sdata['status'];
$adhaar = $sdata['adhaar'];
$pan = $sdata['doc_pan'];

$passbook = $sdata['doc_passbook'];
$business = $sdata['doc_ownbusiness'];
$legalFee = $sdata['legal_fee'];
$file_charge = $sdata['file_charge'];
$site_visit = $sdata['site_visit'];
$total = $sdata['total'];

?>
<!DOCTYPE html>
<html>
<head>
<style>
.invoice-title h2, .invoice-title h3 {
    display: inline-block;
}

.table > tbody > tr > .no-line {
    border-top: none;
}

.table > thead > tr > .no-line {
    border-bottom: none;
}

.table > tbody > tr > .thick-line {
   border-top: 1px solid;
}
.mainborder
{
    border: 1px solid #ccc;
    
}
.bottomborder
{

    border-bottom: 2px solid;

}
hr {
    margin-top: 0px!important;
    margin-bottom: 6px!important;
    border: 0;
    border-top: 1px solid #eee;
}
.table {
    width: 100%;
    margin-bottom: 0px!important;
}
.table-condensed>thead>tr>th, .table-condensed>tbody>tr>th, .table-condensed>tfoot>tr>th, .table-condensed>thead>tr>td, .table-condensed>tbody>tr>td, .table-condensed>tfoot>tr>td {
    padding: 1px!important;
}
b, strong {
    font-weight: 500!important;
}
</style>

</head>
<body>
<link rel="stylesheet" href="assets/bootstrap.min.css">
<link href="http://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
 <script src="assets/bootstrap.min.js"></script>
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script>
/* @license 
 * jQuery.print, version 1.3.1
 *  (c) Sathvik Ponangi, Doers' Guild
 * Licence: CC-By (http://creativecommons.org/licenses/by/3.0/)
 *--------------------------------------------------------------------------*/
(function ($) {
    "use strict";
    // A nice closure for our definitions
    function getjQueryObject(string) {
        // Make string a vaild jQuery thing
        var jqObj = $("");
        try {
            jqObj = $(string)
                .clone();
        } catch (e) {
            jqObj = $("<span />")
                .html(string);
        }
        return jqObj;
    }

    function printFrame(frameWindow) {
        // Print the selected window/iframe
        var def = $.Deferred();
        try {
            setTimeout(function () {
                // Fix for IE : Allow it to render the iframe
                frameWindow.focus();
                try {
                    // Fix for IE11 - printng the whole page instead of the iframe content
                    if (!frameWindow.document.execCommand('print', false, null)) {
                        // document.execCommand returns false if it failed -http://stackoverflow.com/a/21336448/937891
                        frameWindow.print();
                    }
                } catch (e) {
                    frameWindow.print();
                }
                frameWindow.close();
                def.resolve();
            }, 250);
        } catch (err) {
            def.reject(err);
        }
        return def;
    }

    function printContentInNewWindow(content) {
        // Open a new window and print selected content
        var w = window.open();
        w.document.write(content);
        w.document.close();
        return printFrame(w);
    }

    function isNode(o) {
        /* http://stackoverflow.com/a/384380/937891 */
        return !!(typeof Node === "object" ? o instanceof Node : o && typeof o === "object" && typeof o.nodeType === "number" && typeof o.nodeName === "string");
    }
    $.print = $.fn.print = function () {
        // Print a given set of elements
        var options, $this, self = this;
        // console.log("Printing", this, arguments);
        if (self instanceof $) {
            // Get the node if it is a jQuery object
            self = self.get(0);
        }
        if (isNode(self)) {
            // If `this` is a HTML element, i.e. for
            // $(selector).print()
            $this = $(self);
            if (arguments.length > 0) {
                options = arguments[0];
            }
        } else {
            if (arguments.length > 0) {
                // $.print(selector,options)
                $this = $(arguments[0]);
                if (isNode($this[0])) {
                    if (arguments.length > 1) {
                        options = arguments[1];
                    }
                } else {
                    // $.print(options)
                    options = arguments[0];
                    $this = $("html");
                }
            } else {
                // $.print()
                $this = $("html");
            }
        }
        // Default options
        var defaults = {
            globalStyles: true,
            mediaPrint: false,
            stylesheet: null,
            noPrintSelector: ".no-print",
            iframe: true,
            append: null,
            prepend: null,
            manuallyCopyFormValues: true,
            deferred: $.Deferred()
        };
        // Merge with user-options
        options = $.extend({}, defaults, (options || {}));
        var $styles = $("");
        if (options.globalStyles) {
            // Apply the stlyes from the current sheet to the printed page
            $styles = $("style, link, meta, title");
        } else if (options.mediaPrint) {
            // Apply the media-print stylesheet
            $styles = $("link[media=print]");
        }
        if (options.stylesheet) {
            // Add a custom stylesheet if given
            $styles = $.merge($styles, $('<link rel="stylesheet" href="' + options.stylesheet + '">'));
        }
        // Create a copy of the element to print
        var copy = $this.clone();
        // Wrap it in a span to get the HTML markup string
        copy = $("<span/>")
            .append(copy);
        // Remove unwanted elements
        copy.find(options.noPrintSelector)
            .remove();
        // Add in the styles
        copy.append($styles.clone());
        // Appedned content
        copy.append(getjQueryObject(options.append));
        // Prepended content
        copy.prepend(getjQueryObject(options.prepend));
        if (options.manuallyCopyFormValues) {
            // Manually copy form values into the HTML for printing user-modified input fields
            // http://stackoverflow.com/a/26707753
            copy.find("input, select, textarea")
                .each(function () {
                    var $field = $(this);
                    if ($field.is("[type='radio']") || $field.is("[type='checkbox']")) {
                        if ($field.prop("checked")) {
                            $field.attr("checked", "checked");
                        }
                    } else if ($field.is("select")) {
                        $field.find(":selected")
                            .attr("selected", "selected");
                    } else {
                        $field.attr("value", $field.val());
                    }
                });
        }
        // Get the HTML markup string
        var content = copy.html();
        // Notify with generated markup & cloned elements - useful for logging, etc
        try {
            options.deferred.notify('generated_markup', content, copy);
        } catch (err) {
            console.warn('Error notifying deferred', err);
        }
        // Destroy the copy
        copy.remove();
        if (options.iframe) {
            // Use an iframe for printing
            try {
                var $iframe = $(options.iframe + "");
                var iframeCount = $iframe.length;
                if (iframeCount === 0) {
                    // Create a new iFrame if none is given
                    $iframe = $('<iframe height="0" width="0" border="0" wmode="Opaque"/>')
                        .prependTo('body')
                        .css({
                            "position": "absolute",
                            "top": -999,
                            "left": -999
                        });
                }
                var w, wdoc;
                w = $iframe.get(0);
                w = w.contentWindow || w.contentDocument || w;
                wdoc = w.document || w.contentDocument || w;
                wdoc.open();
                wdoc.write(content);
                wdoc.close();
                printFrame(w)
                    .done(function () {
                        // Success
                        setTimeout(function () {
                            // Wait for IE
                            if (iframeCount === 0) {
                                // Destroy the iframe if created here
                                $iframe.remove();
                            }
                        }, 100);
                    })
                    .fail(function (err) {
                        // Use the pop-up method if iframe fails for some reason
                        console.error("Failed to print from iframe", err);
                        printContentInNewWindow(content);
                    })
                    .always(function () {
                        try {
                            options.deferred.resolve();
                        } catch (err) {
                            console.warn('Error notifying deferred', err);
                        }
                    });
            } catch (e) {
                // Use the pop-up method if iframe fails for some reason
                console.error("Failed to print from iframe", e.stack, e.message);
                printContentInNewWindow(content)
                    .always(function () {
                        try {
                            options.deferred.resolve();
                        } catch (err) {
                            console.warn('Error notifying deferred', err);
                        }
                    });
            }
        } else {
            // Use a new window for printing
            printContentInNewWindow(content)
                .always(function () {
                    try {
                        options.deferred.resolve();
                    } catch (err) {
                        console.warn('Error notifying deferred', err);
                    }
                });
        }
        return this;
    };
})(jQuery);

</script>
<style>
@media print
    {
        #non-printable { display: none !important; }
        #printable { display: block !important; }
        #nav{display: none !important;}
        #mm{display: none !important;}
        #mms{display: none !important;}
        #ssmm{display: none !important;}
    }
	
	.bold
	{
    font-weight: bold;
	}
    .images
    {
            margin-top: -17px;
    margin-left: -15px;
    }
    @media print {
    .images
    {
            margin-top: -17px;
    margin-left: -15px;height: 80px;width: 340px;
    }



}
hr{
	margin-top: 1% !important;
	margin-bottom: 1% !important;
}

</style>

<!------ Include the above in your HEAD tag ---------->

<div class="mainborder" id="page-content">
<div class="container" style="    border: 1px solid #ccc;">
<div class="row" >
    			<div class="col-xs-6">
    				<address style="    margin-bottom: 10px;">
    				<strong><h4 align="center">GST NO. 07CPNPS0473P1Z1 </h4></strong>
                   
    				</address>
    			</div>
				<div class="col-xs-6">
    				<address style="    margin-bottom: 10px;">
    				<strong><h4 align="center">MOB: 9999999999</h4></strong>
                   
    				</address>
    			</div>
				</div>
    <div class="row">
	
             <div class="col-xs-12" style="height: 150px;">
            <div class="invoice-title">
            <div class="pull-center"><em><h1 align="center" style="font-size:50px;">SHREE ASSOCIATES</h1></em>
                <p class="text-center">
				<span class="bold">
					ALL TYPE FLATS:- LIG, MIG HIG, LAND AND PROPERTY, WITH BANK FINANCE AND OWN FINANCE FACILITY AVAILABLE
				</span>
				<br>
				<span class="bold">
					Add:- B.M. Market, Main Road, Kartar Nagar, 4th Pusta, Delhi-110053
				</span>
				</p>
              
                </div>
            </div>

            </div>
       
			</div>
		<hr style="border:1px solid #000;">
    		<div class="row">
    			<div class="col-xs-12" style="">
    				<address style="    margin-bottom: 10px;">
    			 <p>
					 <span class="bold">FILL NO : <?php echo 100+$sn; ?></span>
					 <span class="bold">DATE : <?php echo trim($date); ?></span>
					 <span class="bold">/MOB : <?php echo trim($phone); ?></span>
				 </p>
                 
    				</address>
    			</div>
    			
    		</div>
    
	<div class="row">
    			<div class="col-xs-6" style="">
    				<address style=" margin-bottom: 10px;">
    			 <p><span class="bold">SOCIETY CARD NO. </span></p>
                 
    				</address>
    			</div>
    			
				<div class="col-xs-6" style="">
    				<address style="    margin-bottom: 10px;">
    			 <p><span class="bold"><?php echo trim($s_card_no); ?></span></p>
                 
    				</address>
    			</div>
    		</div>
	
	<div class="row">
    			<div class="col-xs-6" style="">
    				<address style=" margin-bottom: 10px;">
    			 <p><span class="bold">1) Name </span></p>
				  <p><span class="bold">2) S/o W/o  </span></p>
				  <p><span class="bold">3) Age   </span></p>
				                    
    				</address>
    			</div>
				
    			
				<div class="col-xs-6" style="">
    				<address style="    margin-bottom: 10px;">
					 <p><span class="bold text-uppercase"><?php echo trim($name); ?></span></p>
					 <p><span class="bold"><?php echo trim($guardian); ?></span></p>
					 <p><span class="bold"><?php echo trim($age); ?></span></p>
				  
    				</address>
    			</div>
				<div class="col-xs-12" style="">
					<address style=" margin-bottom: 10px;">
						<p><span class="bold">4) 
						<?php 
						if($status == 'married'){
						?>
							Married (<span class="glyphicon glyphicon-ok" ></span>)
						<?php 
						}else{
						?>
							Married ( )
						<?php 
						}
						?>
						<?php 
						if($status == 'unmarried'){
						?>
							Unmarried (<span class="glyphicon glyphicon-ok" ></span>)
						<?php 
						}else{
						?>
							Unmarried ( )
						<?php 
						}
						?>
						<?php 
						if($status == 'handicap'){
						?>
							Handicap (<span class="glyphicon glyphicon-ok" ></span>)
						<?php 
						}else{
						?>
							Handicap ( )
						<?php 
						}
						?>
						<?php 
						if($status == 'blind'){
						?>
							Blind (<span class="glyphicon glyphicon-ok" ></span>)
						<?php 
						}else{
						?>
							Blind ( )
						<?php 
						}
						?>
						<?php 
						if($status == 'widow'){
						?>
							Widow (<span class="glyphicon glyphicon-ok" ></span>) </span></p>
						<?php 
						}else{
						?>
							Widow ( )
						<?php 
						}
						?>
						 
					</address>
				</div>
    		</div>
	
	<div class="row">
    			<div class="col-xs-12" style="">
    				<address style=" margin-bottom: 10px;">
    			 <p><span class="bold">DOCUMENTS:- </span></p>
                 
    				</address>
    			</div>
    			
    		</div>
	
 
    
	<div class="row">
    			<div class="col-xs-6" style="">
    				<address style=" margin-bottom: 10px;">
    			 <p><span class="bold">(1) Adhar card  </span></p>
				  <p><span class="bold">(2) Pan card  </span></p>
				  <p><span class="bold">(3) Bank pass book   </span></p>
				   <p><span class="bold">(4) Occupation </span></p>
                 
    				</address>
    			</div>
    			
				<div class="col-xs-6" style="">
    				<address style="    margin-bottom: 10px;">
					  <p><span class="bold"> <?php echo trim($s_card_no); ?></span></p>
					  <?php 
						if($adhaar == 1){
						?>
							<p><span class="bold">(<span class="glyphicon glyphicon-ok" ></span>)</span></p>
						<?php 
						}else{
						?>
							<p><span class="bold">( )</span></p>
						<?php 
						}
						?>
					  <?php 
						if($pan == 1){
						?>
							<p><span class="bold">(<span class="glyphicon glyphicon-ok" ></span>)</span></p>
						<?php 
						}else{
						?>
							<p><span class="bold">( )</span></p>
						<?php 
						}
						?>
					  					  
					  <p>
						  <span class="bold">
						  <?php 
							if($business == "service"){
							?>
								Service (<span class="glyphicon glyphicon-ok" ></span>)
							<?php 
							}else{
							?>
								Service ( )
							<?php 
							}
							?>
							<?php 
							if($business == "business"){
							?>
								Own Business (<span class="glyphicon glyphicon-ok" ></span>)
							<?php 
							}else{
							?>
								Own Business ( )
							<?php 
							}
							?>
					  									
						  </span>
					  </p>
					</address>
    			</div>
    		</div>
			<hr style="border:1px solid #000;">
			
			<div class="row">
    			<div class="col-xs-12" style="">
    				<address style=" margin-bottom: 10px;">
    			 <p><span class="bold">PROCESSING CHARGE:- </span></p>
                 
    				</address>
    			</div>
    			
    		</div>
			
			
			
			<div class="row">
    			<div class="col-xs-12" style="">
    				<address style=" margin-bottom: 10px;">
					<div class="col-xs-6" style="">
					  <p><span class="bold">LEGAL FEE   </span></p>
					  <p><span class="bold">FILE AND PAPER CHARGE  </span></p>
					  <p><span class="bold">SITES VISIT CHARGE    </span></p>
					  <hr>
					   <p><span class="bold">SUB TOTAL   </span></p>
					  <p><span class="bold">GST @ 18%  </span></p>
					  <?php  
						if($status == "blind" || $status == "handicap"){
					  ?>
					  <p><span class="bold">TOTAL   </span></p>
					  <p><span class="bold">DISCOUNT 100%   </span></p>
					  <p><span class="bold">TOTAL   </span></p>
						<?php }else{  ?>
						<p><span class="bold">TOTAL   </span></p>
						<?php }  ?>
					</div>
					<div class="col-xs-6" style="">
					  <p><span class="bold">RS. <?php echo trim($legalFee); ?>/-   </span></p>
					  <p><span class="bold">RS. <?php echo trim($file_charge); ?>/-   </span></p>
					  <p><span class="bold">RS. <?php echo trim($site_visit); ?>/-   </span></p>
					  <hr>
					  <p><span class="bold">RS. <?php echo $t = trim($legalFee+$file_charge+$site_visit); ?>/-   </span></p>
					  <p><span class="bold">RS. <?php echo $t*0.18; ?>/-   </span></p>
					  <?php  
						if($status == "blind" || $status == "handicap"){
					  ?>
					  <p><span class="bold">RS. <?php echo trim($total); ?>/-  </span></p>
					  <p><span class="bold"><BR></span></p>
					  <p><span class="bold">RS. 0/-  </span></p>
					  
					  <?php 
						}else{
					  ?>
					  <p><span class="bold">RS. <?php echo trim($total); ?>/-  </span></p>
					  <?php 
						}
					  ?>
					  
					</div>
    				</address>
    			</div>
    			
				
    		</div>
			
			<hr style="border:1px solid #000;">
			<div class="row">
    			<div class="col-xs-12" style="">
    				<address style=" margin-bottom: 10px;">
    			 <p class="text-justify">If you visits all sites and after visiting all sites you will not interest to finance anyone of then
by any reason then the processing fees will not return and if you will purchase any flat then
your processing fees will be adjust in your flats/land amount. </p>
                 
    				</address>
    			</div>
    			
    		</div>
			
			
			
			 
    
	<div class="row" style="margin-top:6%;">
    			<div class="col-xs-6" style="">
    				<address style=" margin-bottom: 10px;">
						<p><span class="bold">shreeassociates@gmail.com</span></p>
    				</address>
    			</div>
    			
				<div class="col-xs-6" style="">
    				<address style="    margin-bottom: 10px;">
						<p style="float:right"><span class="bold">(SIGNATURE) </span></p>
    				</address>
    			</div>
    </div>
			

<div class="col-xs-12" id="mm">
<br>
<div class="row" >
<div class="text-center no-print"> 
	<a class="btn btn-primary btn-lg print-btn" onClick="window.print()" style="margin-bottom:1%">
        <i class="fa fa-print"></i> Print
    </a> 
	
                       <!--   <a class="btn btn-primary btn-lg print-btn" onClick="jQuery('#page-content').print()">
                            <i class="fa fa-print"></i> Print
                          </a> -->
                        </div>  
</div>
</div>
			
</div>



</div>
