<?php 
require_once 'bin/submit.php';

$sql = mysqli_query($con, "SELECT id FROM info WHERE id = (SELECT MAX(id) FROM info)");
$data = mysqli_fetch_assoc($sql);
$sn = $data['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>SHREE ASSOCIATES</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="assets/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css.css">
  <script src="assets/jquery.min.js"></script>
  <script src="assets/bootstrap.min.js"></script>
  <!-- <script src="assets/js.js"></script> -->
  <link href="assets/css.css" rel="stylesheet" type="text/css"/>
  
  <style>
      .left{
          float: left;
      }
      .right{
          float: right;
      }
  </style>
</head>
<body class="form-body">

<div class="container">
    <div style="max-width: 100%">
<!--        <strong class="text-left"> GST NO. 07CPNPS0473P1Z1</strong>
        <strong class="text-right"> MOB: 9999999999</strong>-->
        
        <em><h1 class="text-center ">SHREE ASSOCIATES</h1></em>
        <p class="text-center">ALL TYPE FLATS:- LIG, MIG HIG, LAND AND PROPERTY, WITH BANK FINANCE</p>
        <p class="text-center">AND OWN FINANCE FACILITY AVAILABLE</p>
        <p class="text-center">Add:- B.M. Market, Main Road, Kartar Nagar, 4 th Pusta, Delhi-110053</p>
    </div>
    <div >
        <form action="search.php" method="get" class="left">
            <input  type="number" placeholder="  Search" name="id">
            <button class="glyphicon glyphicon-search btn btn-info"></button>
        </form>
        
        <form action="search.php" method="get" class="left">
            &nbsp;&nbsp;&nbsp;
            <input  type="number" placeholder="  Update" name="upd">
            <button class="glyphicon glyphicon-pencil btn btn-info"></button>
        </form>
         
    </div>
    <br>
    <br>
<form class="well form-horizontal" action="bin/get.php" method="post" autocomplete="off" id="contact_form">
<fieldset class="fieldset">

<!-- Form Name -->
<div style="max-width:100%">
<div class="form-group">
  <label class="col-md-2 control-label">File No.</label>  
  <div class="col-md-2 inputGroupContainer">
  <div class="input-group">
  
      <input disabled class="form-control"  value="AALS@<?php echo 101+$sn; ?>">
    </div>
  </div>
  
  <label class="col-md-1 control-label">DATE</label>  
  <div class="col-md-2 inputGroupContainer">
  <div class="input-group">
  
      <input  name="form_date" class="form-control" required type="date">
    </div>
	  
  </div>

  <label class="col-md-1 control-label">MOB:-</label>  
  <div class="col-md-2 inputGroupContainer">
  <div class="input-group">
  
      <input  name="phone" placeholder="Ex : 98*******" maxlength="10" required class="form-control" type="tel">
    </div>
  </div>
</div>

</div>

<!-- Text input-->

<div class="form-group">
  <label class="col-md-4 control-label">SOCIETY CARD NO. </label>  
  <div class="col-md-4 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-credit-card"></i></span>
  <input  name="s_card_no" class="form-control" required  type="number">
    </div>
  </div>
</div>

<!-- Text input-->

<div class="form-group">
  <label class="col-md-4 control-label" >Name</label> 
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input name="name"  class="form-control" required type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-4 control-label" >S/o W/o </label> 
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input name="guardian"  class="form-control" required type="text">
    </div>
  </div>
</div>
<div class="form-group">
  <label class="col-md-4 control-label" >Age</label> 
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input name="age"  class="form-control" required type="number">
    </div>
  </div>
</div>
<div class="form-group">
    <label class="col-md-4 control-label">Select Status  </label>
    <div class="col-md-4">
        <div class="select">
            <select class="form-control" name="form_status" required onchange="status(this);">
                <option value="">Select</option>
                <option value="married">Married</option>
                <option value="unmarried">Unmarried</option>
                <option value="widow">Widow</option>
                <option value="blind">Blind</option>
                <option value="handicap">Handicap</option>
            </select>
        </div>
        
    </div>
</div>

<strong class="col-md-8 col-md-offset-2"><h3 class="text-left">Documents:- </h3></strong>

<!-- Check Box input-->
<div class="form-group">
    <label class="col-md-4 control-label">Adhaar No. </label>
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-credit-card"></i></span>
        <input  name="adhaar" class="form-control" required placeholder="Adhaar Number"  type="number">
    </div>
    </div>
    
</div>
<div class="form-group">
    <label class="col-md-4 control-label">Pan card </label>
    <div class="col-md-4">
        <div class="checkbox">
            <label>
                <input type="checkbox" required name="pan" /> 
            </label>
        </div>
        
    </div>
</div>
<div class="form-group">
    <label class="col-md-4 control-label">Bank Passbook</label>
    <div class="col-md-4">
        <div class="checkbox">
            <label>
                <input type="checkbox" required name="passbook" /> 
            </label>
        </div>
        
    </div>
</div>
<div class="form-group">
    <label class="col-md-4 control-label">Service </label>
    <div class="col-md-1">
        <div class="radio">
            <label>
                <input type="radio" required value="service" name="ownBusiness" /> 
            </label>
        </div>
        
    </div>
    <label class="col-md-2 control-label">Own Business </label>
    <div class="col-md-1">
        <div class="radio">
            <label>
                <input type="radio" required value="business" name="ownBusiness" /> 
            </label>
        </div>
        
    </div>
</div>
<!-- Check Box input-->
<div class="form-group">
    <label class="col-md-4 control-label text-left">PROCESSING CHARGE </label>
    
</div>

<div class="row hd" id="na" style="border: 0.5px solid #b5b5b5;margin:1%;padding: 1%;">
       
    <div class="col-md-6">
        <div class="col-md-8">LEGAL FEE</div>
        <div class="col-md-4 wd hc">RS. 1000/-</div>
        <div class="col-md-8">FILE AND PAPER CHARGE</div>
        <div class="col-md-4 wd hc">RS. 90/-</div>
        <div class="col-md-8">SITES VISIT CHARGE</div>
        <div class="col-md-4 wd hc">RS. 110/-</div>
        <hr class="col-md-10" style="border: 0.5px solid #b5b5b5;margin: 0px" />
        <div class="col-md-8">SUB TOTAL</div>
        <div class="col-md-4 wd hc">RS. 1200/-</div>
        <div class="col-md-8">GST @ 18%</div>
        <div class="col-md-4 wd hc">RS. 216/-</div>
        <div class="col-md-8">TOTAL</div>
        <div class="col-md-4 wd hc">RS. 1416/-</div>
    </div>
    
</div>
<div class="row hd" id="wd" style="border: 0.5px solid #b5b5b5;margin:1%;padding: 1%;">
       
    <div class="col-md-6">
        <div class="col-md-8">LEGAL FEE</div>
        <div class="col-md-4 wd hc">RS. 500/-</div>
        <div class="col-md-8">FILE AND PAPER CHARGE</div>
        <div class="col-md-4 wd hc">RS. 45/-</div>
        <div class="col-md-8">SITES VISIT CHARGE</div>
        <div class="col-md-4 wd hc">RS. 55/-</div>
        <hr class="col-md-10" style="border: 0.5px solid #b5b5b5;margin: 0px">
        <div class="col-md-8">SUB TOTAL</div>
        <div class="col-md-4 wd hc">RS. 600/-</div>
        <div class="col-md-8">GST @ 18%</div>
        <div class="col-md-4 wd hc">RS. 108/-</div>
        <div class="col-md-8">TOTAL</div>
        <div class="col-md-4 wd hc">RS. 708/-</div>
    </div>
    
</div>
<div class="row hd" id="hc_bd" style="border: 0.5px solid #b5b5b5;margin:1%;padding: 1%;">
       
    <div class="col-md-6">
        <div class="col-md-8">LEGAL FEE</div>
        <div class="col-md-4 wd hc">RS. 1000/-</div>
        <div class="col-md-8">FILE AND PAPER CHARGE</div>
        <div class="col-md-4 wd hc">RS. 90/-</div>
        <div class="col-md-8">SITES VISIT CHARGE</div>
        <div class="col-md-4 wd hc">RS. 110/-</div>
        <hr class="col-md-10" style="border: 0.5px solid #b5b5b5;margin: 0px">
        <div class="col-md-8">SUB TOTAL</div>
        <div class="col-md-4 wd hc">RS. 1200/-</div>
        <div class="col-md-8">GST @ 18%</div>
        <div class="col-md-4 wd hc">RS. 216/-</div>
        <div class="col-md-8">TOTAL</div>
        <div class="col-md-4 wd hc">RS. 1416/-</div>
        <div class="col-md-8">DISCOUNT 100%</div>
<!--        <div class="col-md-4 wd hc"> 100%</div>-->
        <div class="col-md-8">TOTAL</div>
        <div class="col-md-4 wd hc">RS. 0/-</div>
    </div>
    
</div>

<!-- Text input-->
<div class="text-justify" style="padding:20px">
    If you visits all sites and after visiting all sites you will not interest to finance anyone of then
by any reason then the processing fees will not return and if you will purchase any flat then
your processing fees will be adjust in your flats/land amount.
</div>

<!-- Success message -->
<div class="alert alert-success" role="alert" id="success_message">Success <i class="glyphicon glyphicon-thumbs-up"></i> Thanks for contacting us, we will get back to you shortly.</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4">
      <button type="submit" name="submit" onclick="confirm('Please verify all the information.')" class="btn btn-success" >Submit <span class="glyphicon glyphicon-send"></span></button>
<!--    <button type="submit" class="btn btn-info" >Print <span class="glyphicon glyphicon-print"></span></button>-->
  </div>
</div>

</fieldset>
</form>
</div>
    </div><!-- /.container -->




</body>
<script>
    
function status(val){
//    alert(val.value);
    var get  = val.value; 
    
    if(get == "blind" || get == "handicap"){
        document.getElementById("hc_bd").style.display = "block";
        document.getElementById("wd").style.display = "none";
        document.getElementById("na").style.display = "none";
    
    }else if(get == "widow"){
        document.getElementById("wd").style.display = "block";
        document.getElementById("hc_bd").style.display = "none";
        document.getElementById("na").style.display = "none";
    }else{
        document.getElementById("na").style.display = "block";
        document.getElementById("hc_bd").style.display = "none";
        document.getElementById("wd").style.display = "none";
    }
    
}
    
//function process(){
//    var x = document.getElementById("pCharge");
//    if (x.style.display === "none") {
//      x.style.display = "block";
//    } else {
//      x.style.display = "none";
//    }
//}
</script>
</html>
