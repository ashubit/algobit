-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2018 at 03:21 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shree`
--

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(200) NOT NULL,
  `file_no` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `s_card_no` varchar(200) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `guardian` varchar(255) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `adhaar` varchar(11) DEFAULT NULL,
  `doc_pan` tinyint(4) NOT NULL DEFAULT '0',
  `doc_passbook` tinyint(4) NOT NULL DEFAULT '0',
  `doc_ownbusiness` varchar(255) DEFAULT NULL,
  `legal_fee` varchar(200) DEFAULT NULL,
  `file_charge` varchar(200) DEFAULT NULL,
  `site_visit` varchar(200) DEFAULT NULL,
  `total` varchar(200) DEFAULT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '1',
  `entry_date` datetime DEFAULT NULL,
  `update` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `file_no`, `date`, `phone`, `s_card_no`, `name`, `guardian`, `age`, `status`, `adhaar`, `doc_pan`, `doc_passbook`, `doc_ownbusiness`, `legal_fee`, `file_charge`, `site_visit`, `total`, `flag`, `entry_date`, `update`) VALUES
(1, NULL, '2018-12-21', '1111111111', '44444444', '44444444444444444', 'dfasdf', 3435, 'married', '44444444444', 0, 0, '0', '1000', '90', '110', NULL, 1, '2018-12-08 20:40:05', NULL),
(2, NULL, '0000-00-00', '9999999999', '333333333', 'HANSU TIWARI', 'JP TIWARI', 66, 'blind', '66', 1, 1, 'service', '1000', '90', '110', '0', 1, '2018-12-08 20:49:59', '2018-12-10 19:43:27'),
(3, NULL, '2018-12-08', '9999999999', '33333333333333', 'Hansu Tiwari', 'JP Tiwari', 33, 'married', '8', 1, 1, 'business', '1000', '90', '110', '1416', 1, '2018-12-08 21:49:44', NULL),
(4, NULL, '2018-12-20', '3333333333', '3333333333', 'sss', 'ss', 33, 'handicap', '1', 1, 1, 'service', '1000', '90', '110', '0', 1, '2018-12-10 17:59:34', '2018-12-10 19:38:21'),
(5, NULL, '2018-12-12', '3333333333', '444444444444', '44', 'Ati', 33, 'widow', '9', 1, 1, 'business', '500', '45', '55', '708', 1, '2018-12-10 18:20:58', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
